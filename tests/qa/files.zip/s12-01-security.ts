// tests/qa/s12-01-security.ts
import { api, assert, assertEqual, resetCounters, printSummary, loginAs, login } from "./helpers.ts";

const API = "http://localhost:3000/api/v1";

async function rawFetch(method: string, path: string, headers: Record<string, string> = {}, body?: any): Promise<{ status: number; data: any; headers: Headers }> {
  const opts: any = { method, headers: { ...headers } };
  if (body) {
    opts.headers["Content-Type"] = "application/json";
    opts.body = typeof body === "string" ? body : JSON.stringify(body);
  }
  const res = await fetch(`${API}${path}`, opts);
  let data: any;
  try { data = await res.json(); } catch { data = null; }
  return { status: res.status, data, headers: res.headers };
}

async function main() {
  resetCounters();
  console.log("\n🔄 S12-01: Security Tests\n");

  // ─── Authentication Security ───

  // 1. Missing token
  const noAuth = await rawFetch("GET", "/orders");
  assertEqual(noAuth.status, 401, "Missing token → 401 (not 500)");

  // 2. Invalid token
  const badToken = await rawFetch("GET", "/orders", { Authorization: "Bearer garbage123" });
  assertEqual(badToken.status, 401, "Invalid token → 401");

  // 3. Expired/malformed token
  const expiredToken = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxMjM0NTY3ODkwIiwiZXhwIjoxMDAwMDAwMDAwfQ.invalid";
  const expired = await rawFetch("GET", "/orders", { Authorization: `Bearer ${expiredToken}` });
  assertEqual(expired.status, 401, "Expired/malformed token → 401");

  // 4. Empty bearer
  const emptyBearer = await rawFetch("GET", "/orders", { Authorization: "Bearer " });
  assertEqual(emptyBearer.status, 401, "Empty bearer → 401");

  // ─── Rate Limiting ───

  // 5. Login rate limit
  console.log("  Testing rate limiting (11 failed logins)...");
  let got429 = false;
  for (let i = 1; i <= 15; i++) {
    const res = await rawFetch("POST", "/auth/login", {}, { email: "ratelimit-test@maxmarket.com", password: "wrong" });
    if (res.status === 429) {
      got429 = true;
      console.log(`    Got 429 at attempt ${i}`);
      break;
    }
  }
  assert(got429, "Rate limiting triggers 429 after repeated failed logins");

  // ─── Input Validation ───

  // 6. SQL injection in login
  const sqli = await rawFetch("POST", "/auth/login", {}, {
    email: "admin@test.com'; DROP TABLE users; --",
    password: "test",
  });
  assert(sqli.status === 401 || sqli.status === 422 || sqli.status === 400, "SQL injection → 401/422/400 (not 500)", { status: sqli.status });

  // 7. XSS in order notes
  const agent = await loginAs("agent1");
  const admin = await loginAs("admin");

  // Get a variant with stock
  const stockRes = await api("GET", "/inventory/stock", admin.accessToken);
  const stockEntry = (stockRes.data?.data || stockRes.data || [])[0];
  const variantId = stockEntry?.variantId;

  const clientsRes = await api("GET", `/users/${agent.user.id}/clients`, agent.accessToken);
  const clients = clientsRes.data?.data || clientsRes.data || [];
  const clientId = clients[0]?.id || clients[0]?.clientId;

  const xssOrder = await api("POST", "/orders", agent.accessToken, {
    clientId,
    lineItems: [{ variantId, qty: 1, warehouseId: "00000000-0000-0000-0000-000000000010" }],
    notes: "<script>alert('xss')</script>",
  });
  assertEqual(xssOrder.status, 201, "XSS in notes accepted (stored as string)");
  if (xssOrder.data?.id) {
    const getOrder = await api("GET", `/orders/${xssOrder.data.id}`, agent.accessToken);
    const notes = getOrder.data?.notes;
    assert(
      typeof notes === "string" && notes.includes("<script>"),
      "Notes returned as raw string (not executed/sanitized to empty)"
    );
  }

  // 8. Oversized payload
  const bigPayload = { data: "x".repeat(2 * 1024 * 1024) };
  const oversized = await rawFetch("POST", "/orders", { Authorization: `Bearer ${agent.accessToken}` }, bigPayload);
  assert(
    oversized.status === 413 || oversized.status === 422 || oversized.status === 400,
    "Oversized payload → 413/422/400 (not 500)",
    { status: oversized.status }
  );

  // 9. Empty body on required endpoint
  const emptyBody = await rawFetch("POST", "/users", { Authorization: `Bearer ${(await loginAs("super_admin")).accessToken}`, "Content-Type": "application/json" });
  assert(
    emptyBody.status === 400 || emptyBody.status === 422,
    "Empty body on POST /users → 400/422 (not 500)",
    { status: emptyBody.status }
  );

  // ─── Security Headers ───

  // 10. Headers present
  const headersRes = await fetch(`${API}/catalog/products`);
  // Check common security headers — some may or may not be present
  const hasCorrelation = headersRes.headers.has("x-correlation-id") || headersRes.headers.has("x-request-id");
  assert(hasCorrelation, "X-Correlation-ID or X-Request-ID header present");

  const hasContentType = headersRes.headers.has("x-content-type-options");
  const hasFrameOptions = headersRes.headers.has("x-frame-options");
  console.log(`  Security headers: X-Content-Type-Options=${hasContentType}, X-Frame-Options=${hasFrameOptions}`);
  // Log but don't fail — these are nice-to-have for API servers
  if (hasContentType) assert(true, "X-Content-Type-Options present");
  else console.log("  ℹ️  X-Content-Type-Options not set (recommend adding)");
  if (hasFrameOptions) assert(true, "X-Frame-Options present");
  else console.log("  ℹ️  X-Frame-Options not set (recommend adding for any HTML responses)");

  // ─── Sensitive Data ───

  // 11. Login response has no refresh token in body
  const loginRes = await rawFetch("POST", "/auth/login", {}, {
    email: "agent1@maxmarket.com",
    password: "ChangeMe1!",
  });
  const loginKeys = Object.keys(loginRes.data || {});
  const hasRefreshInBody = loginKeys.some(k => k.toLowerCase().includes("refresh"));
  assert(!hasRefreshInBody, "Login response does NOT contain refresh token in body", { keys: loginKeys });

  // 12. Error responses don't include stack traces
  const errorRes = await rawFetch("GET", "/nonexistent-endpoint");
  const errorBody = JSON.stringify(errorRes.data || {});
  assert(!errorBody.includes("at ") || !errorBody.includes(".js:"), "Error response does not include stack trace");

  return printSummary("S12-01: Security Tests");
}

main().catch(e => { console.error("Fatal error:", e); process.exit(1); });
